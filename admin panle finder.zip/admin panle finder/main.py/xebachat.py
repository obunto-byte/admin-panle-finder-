#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RED ATTACK - Web Security Auditor
by XEBAC HAT
Usage: python redattack.py
Requirements: pip install requests beautifulsoup4 dnspython paramiko
"""

import sys
import os
import re
import io
import json
import time
import socket
import zipfile
import argparse
import threading
from datetime import datetime
from urllib.parse import urljoin, urlparse, parse_qs, urlencode, urlunparse
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from bs4 import BeautifulSoup

# Optional libraries
try:
    import dns.resolver
    HAVE_DNS = True
except ImportError:
    HAVE_DNS = False

try:
    import paramiko
    HAVE_PARAMIKO = True
except ImportError:
    HAVE_PARAMIKO = False

try:
    import ftplib
    HAVE_FTP = True
except ImportError:
    HAVE_FTP = False


# ═════════════════════════════════ ══════════════════════════════════
# COLORS
# ═════════════════════════════════ ══════════════════════════════════
GREEN = "\033[92m"
RED = "\033[91m"  # Changed REJECT to RED for clarity
YELLOW = "\033[93m"
CYAN = "\033[96m"
MAGENTA = "\033[95m"
WHITE = "\033[97m"
RESET = "\033[0m"
BOLD = "\033[1m"


# ═════════════════════════════════ ══════════════════════════════════
# FINDING STORE
# ═════════════════════════════════ ══════════════════════════════════
FINDINGS = []
FINDINGS_LOCK = threading.Lock()

def add_finding(severity, category, url, detail=""):
    with FINDINGS_LOCK:
        FINDINGS.append({
            "time": datetime.now().isoformat(),
            "severity": severity,
            "category": category,
            "url": url,
            "detail": str(detail)
        })

def save_report(prefix="xebac_attack_report"):
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_file = f"{prefix}_{ts}.json"
    txt_file = f"{prefix}_{ts}.txt"
    try:
        with open(json_file, "w", encoding="utf-8") as f:
            json.dump(FINDINGS, f, indent=2, ensure_ascii=False)
        
        with open(txt_file, "w", encoding="utf-8") as f:
            for it in FINDINGS:
                f.write(f"[{it['severity']:8}] {it['category']:15} | {it['url']}\n")
                if it["detail"]:
                    f.write(f"    {it['detail']}\n")
                    
        print(f"{GREEN}[+] Report saved:{RESET}")
        print(f"    {json_file}")
        print(f"    {txt_file}")
    except Exception as e:
        print(f"{RED}[!] Failed to write report: {e}{RESET}")

def print_summary():
    print(f"\n{CYAN}{BOLD}═══ SCAN SUMMARY ═══{RESET}")
    if not FINDINGS:
        print(f"{GREEN}No findings.{RESET}")
        return
        
    counts = {}
    for f in FINDINGS:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1
        
    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
        if sev in counts:
            color = RED if sev in ("CRITICAL", "HIGH") else YELLOW if sev == "MEDIUM" else GREEN
            print(f"  {color}{sev:9}: {counts[sev]}{RESET}")
    print(f"  {WHITE}Total    : {len(FINDINGS)}{RESET}")


# ═════════════════════════════════ ══════════════════════════════════
# ASCII BANNER (Changed to XEBAC HAT)
# ═════════════════════════════════ ══════════════════════════════════
def print_banner():
    banner = f"""{RED}{BOLD}
    ██   ██ ███████ ██████   █████   ██████      ██   ██  █████  ████████ 
     ██ ██  ██      ██   ██ ██   ██ ██           ██   ██ ██   ██    ██    
      ███   █████   ██████  ███████ ██           ███████ ███████    ██    
     ██ ██  ██      ██   ██ ██   ██ ██           ██   ██ ██   ██    ██    
    ██   ██ ███████ ██████  ██   ██  ██████      ██   ██ ██   ██    ██    
{RESET}{CYAN}         [ FTP/SSH · PORT · BACKUP · GIT/SVN/ENV · ADMIN PANEL ]
{RESET}{YELLOW}{BOLD}                       by XEBAC HAT{RESET}
{RESET}{WHITE}                Web Security Auditor v2.0{RESET}
"""
    print(banner)


# ═════════════════════════════════ ══════════════════════════════════
# WORD LISTS
# ═════════════════════════════════ ══════════════════════════════════
DEFAULT_CREDS = [
    ("admin", "admin"), ("admin", "password"), ("admin", "123456"),
    ("admin", "admin123"), ("admin", "letmein"), ("admin", "welcome"),
    ("root", "root"), ("root", "toor"), ("root", "123456"), ("root", "password"),
    ("administrator", "administrator"), ("administrator", "password"),
    ("user", "user"), ("test", "test"), ("guest", "guest"),
    ("ftp", "ftp"), ("ftpuser", "ftpuser"), ("www", "www"), ("web", "web"),
]

ADMIN_PATHS = [
    "/admin", "/admin/", "/administrator", "/administrator/",
    "/wp-admin", "/wp-login.php", "/login", "/login.php", "/signin",
    "/panel", "/cpanel", "/dashboard", "/manage", "/admin.php",
    "/admin/login", "/admin/login.php", "/adminpanel", "/admin_area",
    "/user/login", "/users/login", "/admin/index.php", "/backend",
    "/moderator", "/webadmin", "/admin/login.html", "/controlpanel",
]

BACKUP_PATHS = [
    "backup.zip", "backup.tar.gz", "backup.tar", "backup.sql",
    "backup.rar", "backup.7z", "site.zip", "site.tar.gz", 
    "site.tar", "site.rar", "www.zip", "www.tar.gz", "web.zip", 
    "db.sql", "database.sql", "dump.sql", "backup.sql.gz"
]


# ═════════════════════════════════ ══════════════════════════════════
# CORE FUNCTIONS
# ═════════════════════════════════ ══════════════════════════════════

def check_admin_panels(base_url, threads):
    print(f"{CYAN}[*] Checking for Admin Panels...{RESET}")
    
    def scan_path(path):
        url = urljoin(base_url, path)
        try:
            r = requests.get(url, timeout=5, allow_redirects=False)
            if r.status_code in [200, 301, 302, 401, 403]:
                if r.status_code == 200 and ("login" in r.text.lower() or "password" in r.text.lower() or "admin" in r.text.lower()):
                    print(f"  {GREEN}[+] Found Admin Panel: {url}{RESET}")
                    add_finding("HIGH", "ADMIN_PANEL", url, "Potential login page found")
                elif r.status_code in [301, 302]:
                    print(f"  {YELLOW}[?] Possible Admin Redirect: {url} -> {r.headers.get('Location')}{RESET}")
                    add_finding("MEDIUM", "ADMIN_REDIRECT", url, f"Redirects to {r.headers.get('Location')}")
        except requests.RequestException:
            pass

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = [executor.submit(scan_path, path) for path in ADMIN_PATHS]
        for future in as_completed(futures):
            pass # Results handled in scan_path


def check_backup_files(base_url, threads):
    print(f"{CYAN}[*] Checking for Exposed Backups...{RESET}")
    
    def scan_backup(path):
        url = urljoin(base_url, path)
        try:
            # Use GET with stream=True instead of HEAD (some servers block HEAD)
            r = requests.get(url, timeout=5, stream=True, allow_redirects=True)
            if r.status_code == 200:
                content_type = r.headers.get('Content-Type', '')
                # If it's a file download, not an HTML page
                if 'text/html' not in content_type:
                    print(f"  {RED}[!] Exposed Backup Found: {url}{RESET}")
                    add_finding("CRITICAL", "BACKUP_FILE", url, f"Content-Type: {content_type}")
        except requests.RequestException:
            pass

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = [executor.submit(scan_backup, path) for path in BACKUP_PATHS]
        for future in as_completed(futures):
            pass


def main():
    print_banner()
    
    parser = argparse.ArgumentParser(description="XEBAC HAT Web Security Auditor")
    # required=True hata diya gaya hai
    parser.add_argument("-u", "--url", help="Target URL (e.g., http://example.com)")
    parser.add_argument("-t", "--threads", type=int, default=10, help="Number of threads")
    args = parser.parse_args()

    target = args.url
    # Agar URL nahi diya, toh terminal me puchega
    if not target:
        print(f"{YELLOW}[?] No URL provided via command line.{RESET}")
        try:
            target = input(f"{CYAN}Enter Target URL (e.g., http://testphp.vulnweb.com): {RESET}").strip()
        except KeyboardInterrupt:
            print(f"\n{RED}[!] Cancelled by user.{RESET}")
            sys.exit(0)
            
        if not target:
            print(f"{RED}[!] Target URL is required. Exiting.{RESET}")
            sys.exit(1)

    # Format URL
    if not target.startswith("http://") and not target.startswith("https://"):
        target = "http://" + target
    if not target.endswith("/"):
        target += "/"

    print(f"{WHITE}[*] Target: {target}{RESET}")
    print(f"{WHITE}[*] Threads: {args.threads}{RESET}")
    print(f"{WHITE}[*] Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{RESET}\n")

    start_time = time.time()

    # Run checks with threads
    check_admin_panels(target, args.threads)
    check_backup_files(target, args.threads)

    print_summary()
    
    elapsed = time.time() - start_time
    print(f"\n{CYAN}[*] Scan completed in {elapsed:.2f} seconds{RESET}")
    
    if FINDINGS:
        save_report()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{RED}[!] Scan interrupted by user.{RESET}")
        sys.exit(0)